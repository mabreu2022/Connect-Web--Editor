require('dotenv').config();
const db = require('./src/db/firebird');
db.query('SELECT COUNT(*) AS TOTAL FROM TB_USUARIOS')
  .then(res => {
    console.log('QUERY SUCCESS! Total users:', res[0].total);
    process.exit(0);
  })
  .catch(err => {
    console.error('QUERY FAILED:', err.message);
    process.exit(1);
  });
